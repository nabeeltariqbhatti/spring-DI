package spring.learner.msscbreweryclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsscBreweryClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
